import java.io.*;
import java.util.*;
public class TestClass {
    public static void main(String[] args) throws IOException {
        //taking n inputs
        Scanner scanner=new Scanner(System.in);
    int N=scanner.nextInt();
    scanner.nextLine();
    String[]S=new String[N];
    for(int i=0;i<N;i++)
    {
        S[i]=scanner.nextLine().trim();
    }
    String out_=smallestString(N,S);
        System.out.println(out_);
        scanner.close();
    }
    static String generateNextString(String s){
        int len=s.length();
        StringBuilder sb=new StringBuilder(s);
        for (int i=len-1;i>=0;--i)
        {
            if(sb.charAt(i)!='z')
            {
                sb.setCharAt(i, (char)(sb.charAt(i)+1));
                return sb.toString();
            }
            sb.setCharAt(i,'a');
        }
        return "a".repeat(len+1);//if all char z incr len
    }
    static boolean isSubstringInAny(String sub,String[] candidates)
    {
        for(String candidate:candidates)
        {
            if(candidate.contains(sub)){
                return true;
            }
        }
        return false;
    }
    static String smallestString(int N, String[] S){
        // Write your code here
        String candidate="a";
        while(true) {
            if (!isSubstringInAny(candidate, S)) {
                return candidate;
            }
            candidate = generateNextString(candidate);
        }
    }
}
